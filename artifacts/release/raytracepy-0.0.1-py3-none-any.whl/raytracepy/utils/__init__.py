"""Utility functions for RayTracePy."""
